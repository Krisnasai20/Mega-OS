class ModeManager:
    def __init__(self):
        self.current_mode = 'off'

    def get_mode(self):
        return self.current_mode

    def set_mode(self, new_mode):
        previous_mode = self.current_mode
        self.current_mode = new_mode
        
        # UI mapping config
        mode_config = {
            'off': {
                'output': '>>> SYSTEM DEACTIVATING...\n>>> Entering standby mode.',
                'ui_action': {'action': 'set_mode', 'mode': 'off', 'label': 'OFF', 'prompt': 'sys@megaos:~$', 'condition': 'MINIMAL'}
            },
            'normal': {
                'output': '>>> SYSTEM ACTIVATING...\n>>> Core modules loaded.\n>>> Normal mode engaged.',
                'ui_action': {'action': 'set_mode', 'mode': 'normal', 'label': 'NORMAL', 'prompt': 'sys@megaos:~$', 'condition': 'OPTIMAL'}
            },
            'zero': {
                'output': '>>> INITIATING FLOATING MODE sequence...\n>>> Gravity dampeners disengaged.\n>>> Floating UI protocol activated.',
                'ui_action': {'action': 'set_mode', 'mode': 'zero', 'label': 'FLOATING MODE', 'prompt': 'FLT-CMD ➤', 'condition': 'FLOATING ACTIVE'}
            },
            'secure': {
                'output': '>>> SECURE MODE INITIALIZED.\n>>> Firewall tightened. Biometric locks enabled.',
                'ui_action': {'action': 'set_mode', 'mode': 'secure', 'label': 'SECURE', 'prompt': 'locked@sys#', 'condition': 'LOCKED'}
            },
            'zero-android': {
                'output': '>>> Launching Android OS Environment...\n>>> Type "help" for Android commands or "exit" to return.',
                'ui_action': {'action': 'launch_android', 'prompt': 'FLT-Android ➤'}
            },
            'zero-cloud': {
                'output': '>>> Establishing secure connection to Cloud OS...\n>>> Type "help" for Cloud commands or "exit" to return.',
                'ui_action': {'action': 'launch_cloud', 'prompt': 'FLT-Cloud ➤'}
            }
        }

        # If transitioning from a sub-environment back to zero
        if new_mode == 'zero' and previous_mode in ['zero-android', 'zero-cloud']:
            return {
                'output': '>>> Exited sub-environment. Returning to Floating Mode Shell.',
                'error': '',
                'ui_action': {'action': 'exit_sub', 'prompt': 'FLT-CMD ➤'}
            }

        config = mode_config.get(new_mode, {})
        return {
            'output': config.get('output', ''),
            'error': '',
            'ui_action': config.get('ui_action')
        }
