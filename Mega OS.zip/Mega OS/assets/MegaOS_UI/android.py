def handle_android(cmd_string, mode_manager):
    args = cmd_string.split(' ')
    base_cmd = args[0].lower()

    if base_cmd == 'exit':
        return mode_manager.set_mode('zero')
        
    if base_cmd == 'help':
        output = (
            "🤖 Android OS Commands:\n"
            "  open [app] : Open an Android application\n"
            "  battery    : Check battery status\n"
            "  apps       : List installed applications\n"
            "  ls         : List local storage\n"
            "  cat [file] : Read file contents\n"
            "  edit [file]: Open file in Shell Editor\n"
            "  run [file] : Execute a Python script\n"
            "  clear      : Clear terminal\n"
            "  exit       : Return to Anti-Gravity Shell"
        )
        return {'output': output, 'error': ''}

    if base_cmd == 'battery':
        return {'output': '[Android] Battery Status: 100% (Charging via MegaOS Link)', 'error': ''}

    if base_cmd == 'apps':
        return {'output': '[Android] Installed Apps: Phone, Messages, Camera, Gallery, Maps, Browser, Settings, Files, Music, Calculator, Terminal, Gmail', 'error': ''}

    if base_cmd == 'open':
        app_name = " ".join(args[1:])
        if not app_name:
            return {'output': '', 'error': 'Usage: open [app_name]'}
            
        clean_app_name = app_name.lower().replace('app', '').strip()
        
        return {
            'output': f'[Android] Launching {clean_app_name.capitalize()}...',
            'error': '',
            'ui_action': {'action': 'open_android_app', 'appName': clean_app_name}
        }
    
    # Recognize Android-specific commands, otherwise return None to let CommandHandler handle global ones
    android_specific = ['open', 'battery', 'apps']
    if base_cmd in android_specific:
        return {'output': f'Command {base_cmd} processed by Android subsystem.', 'error': ''}
    
    return None # Fallthrough to main handler for ls, cat, etc.
