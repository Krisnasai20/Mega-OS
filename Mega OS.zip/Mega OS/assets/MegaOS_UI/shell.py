from commands import CommandHandler
from modes import ModeManager

class ShellSession:
    def __init__(self):
        self.mode_manager = ModeManager()
        self.command_handler = CommandHandler(self.mode_manager)

    def process(self, cmd_string):
        return self.command_handler.handle(cmd_string)
