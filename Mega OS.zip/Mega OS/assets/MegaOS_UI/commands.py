from android import handle_android
from cloud import handle_cloud
import subprocess
import os
import datetime

class CommandHandler:
    def __init__(self, mode_manager):
        self.mode_manager = mode_manager

    def handle(self, cmd_string):
        if not cmd_string:
            return {'output': '', 'error': ''}

        args = cmd_string.split(' ')
        base_cmd1 = args[0].lower()
        base_cmd2 = f"{args[0]} {args[1]}".lower() if len(args) > 1 else ""
        
        mode = self.mode_manager.get_mode()

        # Handle system off state early
        if mode == 'off' and base_cmd2 != 'system on' and base_cmd1 != 'help':
            return {'output': '', 'error': 'Command ignored. System is currently OFF. Enter "system on" to activate.'}

        # Sub-environments intercept first
        res = None
        if mode == 'zero-android':
            res = handle_android(cmd_string, self.mode_manager)
        elif mode == 'zero-cloud':
            res = handle_cloud(cmd_string, self.mode_manager)
        
        if res is not None:
            return res

        # Core Modes Command Processing
        if base_cmd2 == 'system on' or base_cmd2 == 'mode normal':
            return self.mode_manager.set_mode('normal')
        if base_cmd2 == 'system off':
            return self.mode_manager.set_mode('off')
        if base_cmd2 == 'mode zero':
            return self.mode_manager.set_mode('zero')
        if base_cmd2 == 'secure mode' or base_cmd2 == 'mode secure':
            return self.mode_manager.set_mode('secure')
        
        if base_cmd2 == 'launch android':
            if mode != 'zero':
                return {'output': '', 'error': 'Android subsystem can only be launched from Anti-Gravity mode ("mode zero").'}
            return self.mode_manager.set_mode('zero-android')
            
        if base_cmd2 == 'launch cloud':
            if mode != 'zero':
                return {'output': '', 'error': 'Cloud environment can only be launched from Floating Mode ("mode zero").'}
            return self.mode_manager.set_mode('zero-cloud')

        if base_cmd1 == 'help':
            return self._get_help()
        if base_cmd1 == 'date':
            return {'output': f"Current System Time: {datetime.datetime.now()}", 'error': ''}
        if base_cmd1 == 'pwd':
            return {'output': r"f:\Mega OS", 'error': ''}
        if base_cmd1 == 'ls' or base_cmd1 == 'dir':
            return self._ls(args)
        if base_cmd1 == 'cat':
            return self._cat(args)
        if base_cmd1 == 'edit':
            return self._edit(args)
        if base_cmd1 == 'mkdir':
            return self._mkdir(args)
        if base_cmd1 == 'rm':
            return self._rm(args)
        if base_cmd1 == 'echo':
            return {'output': " ".join(args[1:]), 'error': ''}
        if base_cmd1 == 'clear':
            return {'output': '', 'error': '', 'ui_action': {'action': 'clear'}}

        if base_cmd1 == 'open':
            if mode in ['zero', 'zero-android']:
                return handle_android(cmd_string, self.mode_manager)
            return {'output': '', 'error': "The 'open' command is only available in Floating Mode or Android Subsystem."}

        if base_cmd1 in ['run', 'python']:
            return self._run_python(args)

        # Fallback to true OS commands
        return self._run_os_command(cmd_string)

    def _get_help(self):
        output = (
            "Available commands:\n"
            "  system on        : Activate normal operations\n"
            "  system off       : Deactivate system to standby\n"
            "  mode zero        : Activate Floating Mode environment\n"
            "  mode secure      : Activate Locked/Secure environment\n"
            "  mode normal      : Switch back to Normal mode\n"
            "  launch android   : [Floating Mode Only] Launch Android Subsystem\n"
            "  launch cloud     : [Floating Mode Only] Launch Cloud Environment\n"
            "  pwd              : Print working directory\n"
            "  ls / dir         : List files in current directory\n"
            "  cat [file]       : Read file contents\n"
            "  edit [file]      : Open file in Shell Editor\n"
            "  mkdir [dir]      : Create a new directory\n"
            "  rm [file]        : Remove a file\n"
            "  run/python [file]: Execute a Python script\n"
            "  echo [text]      : Print text to output\n"
            "  date             : Display current system date and time\n"
            "  clear            : Clear terminal output\n"
            "  help             : Show this message"
        )
        return {'output': output, 'error': ''}

    def _ls(self, args):
        try:
            # Base directory for the OS project
            base_os_dir = r"f:\Mega OS"
            path = base_os_dir
            if len(args) > 1:
                # Basic relative path support
                requested = args[1].strip()
                potential = os.path.join(base_os_dir, requested)
                if os.path.abspath(potential).startswith(os.path.abspath(base_os_dir)):
                    path = potential
            
            if not os.path.exists(path):
                return {'output': '', 'error': f'Directory not found: {path}'}
                
            items = os.listdir(path)
            output = []
            for item in items:
                full_path = os.path.join(path, item)
                if os.path.isdir(full_path):
                    output.append(f"[DIR]  {item}")
                else:
                    size = os.path.getsize(full_path)
                    output.append(f"[FILE] {item} ({size} bytes)")
            
            return {'output': "\n".join(output) if output else "Directory is empty.", 'error': ''}
        except Exception as e:
            return {'output': '', 'error': str(e)}

    def _cat(self, args):
        if len(args) < 2:
            return {'output': '', 'error': 'Usage: cat [filename]'}
        filename = args[1].strip()
        try:
            base_os_dir = r"f:\Mega OS"
            path = os.path.join(base_os_dir, filename)
            if not os.path.abspath(path).startswith(os.path.abspath(base_os_dir)):
                 return {'output': '', 'error': 'Security Violation: Path outside project root.'}
            
            with open(path, 'r', encoding='utf-8') as f:
                return {'output': f.read(), 'error': ''}
        except Exception as e:
            return {'output': '', 'error': str(e)}

    def _edit(self, args):
        if len(args) < 2:
            return {'output': '', 'error': 'Usage: edit [filename]'}
        filename = args[1].strip()
        content = ""
        try:
            base_os_dir = r"f:\Mega OS"
            path = os.path.join(base_os_dir, filename)
            if not os.path.abspath(path).startswith(os.path.abspath(base_os_dir)):
                 return {'output': '', 'error': 'Security Violation: Path outside project root.'}
            
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
            
            return {
                'output': f'Opening {filename} in editor...',
                'error': '',
                'ui_action': {
                    'action': 'open_editor',
                    'filename': filename,
                    'content': content
                }
            }
        except Exception as e:
            return {'output': '', 'error': str(e)}

    def _mkdir(self, args):
        if len(args) < 2:
            return {'output': '', 'error': 'Usage: mkdir [dirname]'}
        dirname = args[1].strip()
        try:
            base_os_dir = r"f:\Mega OS"
            path = os.path.join(base_os_dir, dirname)
            os.makedirs(path, exist_ok=True)
            return {'output': f'Directory created: {dirname}', 'error': ''}
        except Exception as e:
            return {'output': '', 'error': str(e)}

    def _rm(self, args):
        if len(args) < 2:
            return {'output': '', 'error': 'Usage: rm [filename]'}
        filename = args[1].strip()
        try:
            base_os_dir = r"f:\Mega OS"
            path = os.path.join(base_os_dir, filename)
            if os.path.isfile(path):
                os.remove(path)
                return {'output': f'File removed: {filename}', 'error': ''}
            elif os.path.isdir(path):
                os.rmdir(path)
                return {'output': f'Directory removed: {filename}', 'error': ''}
            else:
                return {'output': '', 'error': f'File not found: {filename}'}
        except Exception as e:
            return {'output': '', 'error': str(e)}

    def _run_python(self, args):
        if len(args) < 2:
            return {'output': '', 'error': 'Usage: python <filename>'}
        filename = args[1].strip()
        if filename.endswith('.py'):
            if not os.path.exists(filename):
                return {'output': '', 'error': f"File not found: {filename}"}
            try:
                result = subprocess.run(['python', filename], capture_output=True, text=True, timeout=10)
                out = result.stdout
                if result.stderr:
                    out += f"\n[ERROR]\n{result.stderr}"
                return {'output': out, 'error': ''}
            except Exception as e:
                return {'output': '', 'error': str(e)}
        else:
            return {'output': '', 'error': f"Don't know how to run {filename}. Only .py is supported."}

    def _run_os_command(self, cmd_string):
        try:
            result = subprocess.run(cmd_string, shell=True, capture_output=True, text=True, timeout=5)
            out = result.stdout.strip()
            err = result.stderr.strip()
            if err and not out:
                return {'output': '', 'error': err}
            final_out = out + (f"\n[stderr]\n{err}" if err else "")
            if not final_out:
                return {'output': '', 'error': f'Unknown command: {cmd_string}. Enter "help" for a list of commands.'}
            return {'output': final_out, 'error': ''}
        except Exception as e:
            return {'output': '', 'error': str(e)}
