def handle_cloud(cmd_string, mode_manager):
    args = cmd_string.split(' ')
    base_cmd = args[0].lower()

    if base_cmd == 'exit':
        return mode_manager.set_mode('zero')

    if base_cmd == 'help':
        output = (
            "☁️ Cloud OS Commands:\n"
            "  upload [file]   : Upload a local file to the cloud\n"
            "  download [file] : Download a file from the cloud\n"
            "  usage           : Display cloud resource usage stats\n"
            "  deploy [app]    : Deploy an application to cloud compute nodes\n"
            "  ls              : List remote and local files\n"
            "  cat [file]      : Read file contents\n"
            "  edit [file]     : Open file in Shell Editor\n"
            "  clear           : Clear cloud terminal\n"
            "  connect [server]: Connect to a remote server\n"
            "  exit            : Return to Anti-Gravity Shell"
        )
        return {'output': output, 'error': ''}

    if base_cmd == 'connect':
        server = " ".join(args[1:])
        if not server:
            return {'output': '', 'error': 'Usage: connect [server_name]'}
        return {
            'output': f'[Cloud] Connecting to {server}...\n[Cloud] Connection established. Secure session active.',
            'error': ''
        }

    if base_cmd == 'upload':
        file = " ".join(args[1:])
        if not file:
            return {'output': '', 'error': 'Usage: upload [filename]'}
        return {
            'output': f'[Cloud] Preparing to upload {file}...\n[Cloud] Uploading... 45%\n[Cloud] Upload complete. {file} stored in /cloud_files/',
            'error': ''
        }

    if base_cmd == 'download':
        file = " ".join(args[1:])
        if not file:
            return {'output': '', 'error': 'Usage: download [filename]'}
        return {
            'output': f'[Cloud] Fetching {file}...\n[Cloud] Download complete. {file} saved to local storage.',
            'error': ''
        }

    if base_cmd == 'usage':
        output = (
            "[Cloud] Resource Usage:\n"
            "  CPU: 72% (Spiking across 3 active nodes)\n"
            "  RAM: 48 GB Active\n"
            "  Storage: 1.2 TB / 5 TB Used"
        )
        return {'output': output, 'error': ''}

    if base_cmd == 'deploy':
        app = " ".join(args[1:])
        if not app:
            return {'output': '', 'error': 'Usage: deploy [app_name]'}
        return {
            'output': f'[Cloud] Spinning up container for {app}...\n[Cloud] Container started. Routing network traffic...\n[Cloud] Deployment successful. Application {app} is LIVE.',
            'error': ''
        }
        
    # Recognize Cloud-specific commands, otherwise return None to let CommandHandler handle global ones
    cloud_specific = ['upload', 'download', 'usage', 'deploy', 'connect']
    if base_cmd in cloud_specific:
        return {'output': f'Command {base_cmd} processed by Cloud environment.', 'error': ''}
    
    return None # Fallthrough
