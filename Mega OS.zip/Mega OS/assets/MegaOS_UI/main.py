from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
from shell import ShellSession

# Set the static folder to the project root (two levels up from this file)
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
app = Flask(__name__, static_folder=PROJECT_ROOT, static_url_path='')
CORS(app)

# Global session instance
session = ShellSession()

@app.route('/api/execute', methods=['POST'])
def execute_command():
    data = request.json
    cmd = data.get('command', '').strip()

    if not cmd:
        return jsonify({'output': '', 'error': 'No command provided'})

    result = session.process(cmd)
    return jsonify(result)

@app.route('/api/save', methods=['POST'])
def save_file():
    data = request.json
    filename = data.get('filename')
    content = data.get('content')
    
    if not filename:
        return jsonify({'success': False, 'error': 'No filename provided'})
    
    try:
        # Base directory for the OS project
        base_dir = r"f:\Mega OS"
        file_path = os.path.join(base_dir, filename)
        
        # Security: Prevent escaping the directory
        if not os.path.abspath(file_path).startswith(os.path.abspath(base_dir)):
            return jsonify({'success': False, 'error': 'Security Violation: Path outside project root.'})

        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/')
def serve_index():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory(app.static_folder, path)

if __name__ == '__main__':
    app.run(port=5000, debug=True)
