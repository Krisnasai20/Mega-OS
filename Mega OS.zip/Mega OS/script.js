const currentModeEl = document.getElementById('current-mode');
const sysStatusEl = document.getElementById('sys-status');
const agStatusEl = document.getElementById('ag-status');
const secureStatusEl = document.getElementById('secure-status');
const promptTextEl = document.getElementById('prompt-text');
const cmdInput = document.getElementById('cmd-input');
const outputHistory = document.getElementById('output-history');

let currentMode = 'off';

// Removed JS-based command maps. Logic is now handled by the Python backend.

cmdInput.addEventListener('keydown', function(e) {
    if(e.key === 'Enter') {
        const inputVal = cmdInput.value.trim();
        if(inputVal) {
            processCommand(inputVal);
        }
        cmdInput.value = '';
    }
});

// Click anywhere to focus input (unless clicking a different input or overlay)
document.addEventListener('click', (e) => {
    if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
        cmdInput.focus();
    }
});

function appendOutput(text, className = 'history-line') {
    const line = document.createElement('div');
    line.className = className;
    line.textContent = text;
    outputHistory.appendChild(line);
    outputHistory.scrollTop = outputHistory.scrollHeight;
}

async function processCommand(cmdString) {
    // Echo the prompt + command
    appendOutput(`${promptTextEl.textContent} ${cmdString}`);

    try {
        const response = await fetch('http://localhost:5000/api/execute', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ command: cmdString, mode: currentMode })
        });
        
        const data = await response.json();
        
        // Handle explicit UI actions
        if (data.ui_action) {
            handleUIAction(data.ui_action);
        }

        // Print returned output or errors
        if (data.error) {
            appendOutput(data.error, 'err-msg');
        } else if (data.output) {
            appendOutput(data.output);
        }

    } catch (e) {
        appendOutput(`[Network Error] Could not connect to MegaOS Backend (Flask API not running).`, 'err-msg');
        appendOutput('Start the backend with: cd "f:\\\\Mega OS\\\\assets\\\\MegaOS_UI" && python main.py', 'system-msg');
    }
}

function handleUIAction(actionData) {
    switch (actionData.action) {
        case 'clear':
            outputHistory.innerHTML = '';
            break;
        case 'set_mode':
            document.body.className = `mode-${actionData.mode}`;
            currentMode = actionData.mode;
            currentModeEl.textContent = actionData.label;
            promptTextEl.textContent = actionData.prompt;
            sysStatusEl.textContent = actionData.condition;
            
            agStatusEl.classList.toggle('hidden', currentMode !== 'zero');
            secureStatusEl.classList.toggle('hidden', currentMode !== 'secure');
            break;
        case 'launch_android':
            currentMode = 'zero-android';
            promptTextEl.textContent = actionData.prompt;
            document.getElementById('android-overlay').classList.remove('hidden');
            startAndroidClock();
            break;
        case 'launch_cloud':
            currentMode = 'zero-cloud';
            promptTextEl.textContent = actionData.prompt;
            document.getElementById('cloud-overlay').classList.remove('hidden');
            break;
        case 'exit_sub':
            currentMode = 'zero';
            promptTextEl.textContent = actionData.prompt;
            document.getElementById('android-overlay').classList.add('hidden');
            document.getElementById('cloud-overlay').classList.add('hidden');
            break;
        case 'open_editor':
            openEditor(actionData.filename, actionData.content);
            break;
        case 'open_android_app':
            if (currentMode === 'zero') {
                currentMode = 'zero-android';
                promptTextEl.textContent = 'FLT-Android ➤';
                document.getElementById('android-overlay').classList.remove('hidden');
                startAndroidClock();
            }
            openAndroidApp(actionData.appName);
            break;
    }
}

// Cloud Terminal Input
const cloudInput = document.getElementById('cloud-cmd-input');
if (cloudInput) {
    cloudInput.addEventListener('keydown', function(e) {
        if(e.key === 'Enter') {
            const inputVal = cloudInput.value.trim();
            if(inputVal) {
                processCloudCommand(inputVal);
            }
            cloudInput.value = '';
        }
    });
}

function appendCloudTerminal(text) {
    const term = document.getElementById('cloud-terminal-output');
    const line = document.createElement('div');
    line.textContent = `cloud@megaos:~$ ${text}`;
    term.appendChild(line);
    term.scrollTop = term.scrollHeight;
}

async function processCloudCommand(cmdString) {
    appendCloudTerminal(cmdString);
    try {
        const response = await fetch('http://localhost:5000/api/execute', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ command: cmdString, mode: 'zero-cloud' })
        });
        const data = await response.json();
        if (data.ui_action) handleUIAction(data.ui_action);
        const term = document.getElementById('cloud-terminal-output');
        const line = document.createElement('div');
        if (data.error) {
            line.style.color = '#ff6666';
            line.textContent = data.error;
        } else if (data.output) {
            line.textContent = data.output;
        }
        term.appendChild(line);
        term.scrollTop = term.scrollHeight;
    } catch (e) {
        const term = document.getElementById('cloud-terminal-output');
        const line = document.createElement('div');
        line.style.color = '#ff6666';
        line.textContent = '[Network Error] Backend not running.';
        term.appendChild(line);
        term.scrollTop = term.scrollHeight;
    }
}

// --------- Nested Environments Logic --------- //

// Handled by UI actions now

let androidClockInterval;
function startAndroidClock() {
    const clockEl = document.getElementById('android-clock');
    clearInterval(androidClockInterval);
    const update = () => {
        const d = new Date();
        clockEl.textContent = d.getHours().toString().padStart(2,'0') + ':' + d.getMinutes().toString().padStart(2,'0');
    };
    update();
    androidClockInterval = setInterval(update, 10000);
}

// Handled by UI actions now

// GUI Overlay Actions
function closeOverlay(id) {
    document.getElementById(id).classList.add('hidden');
    // If they close via GUI, also exit the shell mode
    if (id === 'android-overlay' && currentMode === 'zero-android') {
        processCommand('exit');
    } else if (id === 'cloud-overlay' && currentMode === 'zero-cloud') {
        processCommand('exit');
    }
}

// androidAppClick defined below (see line ~187)

function selectCloudSection(sectionName, evt) {
    // Hide all sections
    document.querySelectorAll('.cloud-section').forEach(el => el.classList.add('hidden'));
    // Un-highlight all nav items
    document.querySelectorAll('.cloud-nav-item').forEach(el => el.classList.remove('active'));
    
    // Show correct section
    document.getElementById('cloud-section-' + sectionName).classList.remove('hidden');
    // Highlight correct nav item
    if (evt && evt.target) {
        evt.target.classList.add('active');
    }
}

function openCloudFile(filename) {
    if (filename.endsWith('.c') || filename.endsWith('.py')) {
        let content = '// ' + filename + '\\n';
        if (filename === 'megaos_kernel.c') content = '/* \\n * MegaOS Core Kernel \\n * v1.0.0\\n */\\n\\n#include <stdio.h>\\n\\nint main() {\\n    printf("MegaOS Initialized.\\\\n");\\n    return 0;\\n}';
        if (filename === 'script.py') content = 'def process_data():\\n    print("Processing cloud data...")\\n\\nif __name__ == "__main__":\\n    process_data()';
        openEditor(filename, content);
        return;
    }
    
    // Switch to terminal tab for other file types
    document.querySelectorAll('.cloud-section').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.cloud-nav-item').forEach(el => el.classList.remove('active'));
    document.getElementById('cloud-section-terminal').classList.remove('hidden');
    
    // Highlight terminal nav item (4th item)
    const navItems = document.querySelectorAll('.cloud-nav-item');
    if (navItems.length >= 4) navItems[3].classList.add('active');

    if (filename.endsWith('/')) {
        processCloudCommand('ls ' + filename);
    } else {
        processCloudCommand('download ' + filename);
    }
}

// --------- Android Mockup Apps Logic --------- //

function androidAppClick(appName) {
    const notif = document.getElementById('android-notification');
    notif.textContent = `Opening ${appName}...`;
    notif.classList.remove('hidden');
    
    setTimeout(() => {
        notif.classList.add('hidden');
        openAndroidApp(appName);
    }, 1000);
}

function openAndroidApp(appName) {
    const appView = document.getElementById('android-app-view');
    const appTitle = document.getElementById('app-view-title');
    const allApps = document.querySelectorAll('.mockup-app');
    
    appView.classList.remove('hidden');
    appTitle.textContent = appName;
    
    // Hide all mockups first
    allApps.forEach(app => app.classList.add('hidden'));
    
    const appKey = appName.toLowerCase();
    
    // Map app names to their div IDs
    const appMap = {
        'phone': 'app-phone',
        'camera': 'app-camera',
        'gallery': 'app-gallery',
        'messages': 'app-messages',
        'maps': 'app-maps',
        'gmail': 'app-gmail',
        'settings': 'app-settings',
        'files': 'app-files',
        'music': 'app-music',
        'calculator': 'app-calculator',
        'browser': 'app-browser',
        'terminal': 'app-terminal'
    };
    
    const appId = appMap[appKey];
    if (appId) {
        const el = document.getElementById(appId);
        if (el) {
            el.classList.remove('hidden');
            if (appKey === 'camera') startCamera();
            if (appKey === 'terminal') initAndroidTerminal();
            return;
        }
    }
    
    // Fallback for unknown apps
    const fallback = document.getElementById('app-fallback');
    const fallbackContent = document.getElementById('app-fallback-content');
    fallbackContent.innerHTML = `
        <div style="padding:40px; text-align:center; color:#888;">
            <h3>${appName}</h3>
            <p>This application is currently in development.</p>
            <div style="font-size:3rem; margin-top:20px;">🚧</div>
        </div>
    `;
    fallback.classList.remove('hidden');
}

function closeAndroidApp() {
    document.getElementById('android-app-view').classList.add('hidden');
    stopCamera();
}

// Phone Logic
let phoneNumber = '';
function phoneType(num) {
    if (phoneNumber.length < 15) {
        phoneNumber += num;
        document.getElementById('phone-number-display').textContent = phoneNumber;
    }
}

function phoneCall() {
    if (!phoneNumber) return;
    const display = document.getElementById('phone-number-display');
    display.textContent = 'Calling...';
    setTimeout(() => {
        display.textContent = 'Connected';
        setTimeout(() => {
            display.textContent = 'Line Busy (Demo)';
            phoneNumber = '';
            setTimeout(() => display.textContent = '', 2000);
        }, 2000);
    }, 1500);
}

// Camera Logic
let stream = null;
async function startCamera() {
    try {
        const video = document.getElementById('camera-feed');
        stream = await navigator.mediaDevices.getUserMedia({ video: true });
        video.srcObject = stream;
    } catch (err) {
        console.error("Camera error:", err);
        const video = document.getElementById('camera-feed');
        video.outerHTML = '<div class="camera-feed" style="display:flex; align-items:center; justify-content:center; color:#ff3333;">[!] Camera Access Denied / Not Found</div>';
    }
}

function stopCamera() {
    if (stream) {
        stream.getTracks().forEach(track => track.stop());
        stream = null;
    }
}

function cameraCapture() {
    appendOutput("[Camera] Photo captured and saved to Gallery.", "success-msg");
}

// --------- App-specific Logic --------- //

// Calculator
let calcInput = '';
function calcBtn(val) {
    const display = document.getElementById('calc-display');
    if (!display) return;
    if (val === 'C') { calcInput = ''; display.textContent = '0'; return; }
    if (val === '=') {
        try {
            const result = Function('"use strict"; return (' + calcInput + ')')();
            display.textContent = result;
            calcInput = String(result);
        } catch(e) { display.textContent = 'Error'; calcInput = ''; }
        return;
    }
    calcInput += val;
    display.textContent = calcInput;
}

// Messages
function sendMessage() {
    const input = document.getElementById('msg-input');
    if (!input || !input.value.trim()) return;
    const container = input.closest('.mockup-app').querySelector('div:nth-child(2)');
    const msg = document.createElement('div');
    msg.style.cssText = 'align-self:flex-end;background:#3ddc84;padding:10px 15px;border-radius:15px 15px 0 15px;color:#000;max-width:70%;';
    msg.textContent = input.value.trim();
    container.appendChild(msg);
    input.value = '';
    container.scrollTop = container.scrollHeight;
}

// Music
let musicPlaying = false;
function toggleMusic() {
    musicPlaying = !musicPlaying;
    const btn = document.getElementById('music-play-btn');
    if (btn) btn.textContent = musicPlaying ? '⏸️' : '▶️';
}

// Browser
function browserGo() {
    const url = document.getElementById('browser-url').value;
    const content = document.getElementById('browser-content');
    content.innerHTML = `<div style="color:#3ddc84;padding:20px;">🌐 Navigating to: <b>${url}</b><br><br><span style="color:#888;">Content from external URLs is not available in demo mode.</span></div>`;
}

// Android In-App Terminal
function initAndroidTerminal() {
    const out = document.getElementById('app-term-output');
    if (out && out.children.length === 0) {
        const line = document.createElement('div');
        line.textContent = 'Android Shell v14.2 — type "help" for commands';
        out.appendChild(line);
    }
}

function androidTermCmd(cmd) {
    const out = document.getElementById('app-term-output');
    if (!out || !cmd.trim()) return;
    const echoLine = document.createElement('div');
    echoLine.style.color = '#aaa';
    echoLine.textContent = `android$ ${cmd}`;
    out.appendChild(echoLine);
    const resLine = document.createElement('div');
    const c = cmd.trim().toLowerCase();
    if (c === 'help') resLine.textContent = 'Commands: ls, pwd, date, uname, clear, help';
    else if (c === 'ls') resLine.textContent = 'Downloads/  Pictures/  megaos_kernel.c  script.py';
    else if (c === 'pwd') resLine.textContent = '/home/android';
    else if (c === 'date') resLine.textContent = new Date().toString();
    else if (c === 'uname') resLine.textContent = 'MegaOS Android v14.2 (aarch64)';
    else if (c === 'clear') { out.innerHTML = ''; return; }
    else resLine.textContent = `${cmd}: command not found`;
    out.appendChild(resLine);
    out.scrollTop = out.scrollHeight;
}

// --------- Text Editor Logic --------- //

let currentEditingFile = '';

function openEditor(filename, content = '') {
    currentEditingFile = filename;
    document.getElementById('editor-title').textContent = `📝 Editing: ${filename}`;
    document.getElementById('editor-textarea').value = content;
    document.getElementById('editor-overlay').classList.remove('hidden');
    document.getElementById('editor-textarea').focus();
}

async function saveEditorFile() {
    const content = document.getElementById('editor-textarea').value;
    const filename = currentEditingFile;
    
    if (!filename) return;

    appendOutput(`>>> Saving ${filename}...`);

    try {
        const response = await fetch('http://localhost:5000/api/save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename, content })
        });
        
        const data = await response.json();
        
        if (data.success) {
            appendOutput(`>>> File [${filename}] saved successfully.`, 'success-msg');
            document.getElementById('editor-overlay').classList.add('hidden');
        } else {
            appendOutput(`[Error] ${data.error}`, 'err-msg');
        }
    } catch (e) {
        appendOutput(`[Network Error] Could not connect to backend to save file.`, 'err-msg');
    }
}
